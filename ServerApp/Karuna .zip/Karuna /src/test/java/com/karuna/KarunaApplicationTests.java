package com.karuna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KarunaApplicationTests {

	@Test
	void contextLoads() {
	}

}
